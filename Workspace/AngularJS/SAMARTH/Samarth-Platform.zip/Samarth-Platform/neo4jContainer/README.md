To run the neo4j as container run this command 
	
	cd /path/to/neo4jContainer

	docker-compose -f docker-compose-local-neo4j.yml up -d
	
Then access http://localhost:17474 or http://localhost:7474 it should be running 
