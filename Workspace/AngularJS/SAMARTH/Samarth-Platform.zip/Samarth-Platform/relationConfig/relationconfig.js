var neorelationconfig = function () {
	return {
		'IS_A' : 'IS_A',
		'WAS_A':'WAS_A',
		'Qualification_in':'Qualification_in',
		'Qualified_from':'Qualified_from'
	}
}

module.exports = {
	neorelationconfig : neorelationconfig
}